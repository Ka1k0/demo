<?php
session_start();

$host = 'localhost:3310';
$dbname = 'restaurant_booking';
$username = 'root';
$password = ''; // Обычно пустой пароль в OpenServer

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}
?>