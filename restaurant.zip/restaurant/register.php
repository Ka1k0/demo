<?php
require_once 'config/database.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // Валидация
    if (strlen($login) < 6 || !preg_match('/^[а-яА-Я]+$/u', $login)) {
        $errors[] = 'Логин должен состоять из кириллицы и быть не менее 6 символов';
    }

    if (strlen($password) < 6) {
        $errors[] = 'Пароль должен быть не менее 6 символов';
    }

    if (!preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) {
        $errors[] = 'Телефон должен быть в формате +7(XXX)-XXX-XX-XX';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Некорректный email';
    }

    // Проверка уникальности логина
    $stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
    $stmt->execute([$login]);
    if ($stmt->fetch()) {
        $errors[] = 'Пользователь с таким логином уже существует';
    }

    // Регистрация
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("INSERT INTO users (login, password, first_name, last_name, phone, email) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$login, $hashed_password, $first_name, $last_name, $phone, $email]);
        
        $success = true;
    }
}

require_once 'includes/header.php';
?>

<div class="form-container">
    <h2>Регистрация</h2>
    
    <?php if ($success): ?>
        <div class="message success">
            Регистрация успешна! Теперь вы можете <a href="/login.php">войти</a>.
        </div>
    <?php endif; ?>
    
    <?php if (!empty($errors)): ?>
        <div class="message error">
            <?php foreach ($errors as $error): ?>
                <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div class="form-group">
            <label for="login">Логин (кириллица, не менее 6 символов):</label>
            <input type="text" id="login" name="login" class="form-control" required 
                   pattern="[а-яА-Я]{6,}" title="Только кириллица, не менее 6 символов">
        </div>
        
        <div class="form-group">
            <label for="password">Пароль (не менее 6 символов):</label>
            <input type="password" id="password" name="password" class="form-control" required minlength="6">
        </div>
        
        <div class="form-group">
            <label for="first_name">Имя:</label>
            <input type="text" id="first_name" name="first_name" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label for="last_name">Фамилия:</label>
            <input type="text" id="last_name" name="last_name" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label for="phone">Телефон (+7(XXX)-XXX-XX-XX):</label>
            <input type="tel" id="phone" name="phone" class="form-control" required 
                   pattern="\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}" 
                   title="Формат: +7(XXX)-XXX-XX-XX">
        </div>
        
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" class="form-control" required>
        </div>
        
        <button type="submit" class="btn">Зарегистрироваться</button>
    </form>
    
    <p style="text-align: center; margin-top: 15px;">
        Уже есть аккаунт? <a href="/login.php">Войти</a>
    </p>
</div>

<?php require_once 'includes/footer.php'; ?>