<?php
require_once 'config/database.php';
require_once 'includes/header.php';
?>

<div class="welcome-message">
    <h2>Добро пожаловать в ресторан "Я буду кушац"!</h2>
    <p>Забронируйте столик для незабываемого ужина в уютной атмосфере. Наша команда готова сделать ваш вечер особенным!</p>
    
    <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="/register.php" class="btn" style="width: auto; display: inline-block; margin: 10px;">Зарегистрироваться</a>
        <a href="/login.php" class="btn btn-success" style="width: auto; display: inline-block; margin: 10px;">Войти</a>
    <?php else: ?>
        <a href="/book_table.php" class="btn" style="width: auto; display: inline-block; margin: 10px;">Забронировать столик</a>
        <a href="/bookings.php" class="btn btn-success" style="width: auto; display: inline-block; margin: 10px;">Мои бронирования</a>
    <?php endif; ?>
</div>

<div class="features">
    <div class="feature-card">
        <h3>🎯 Удобное бронирование</h3>
        <p>Выбирайте дату, время и количество гостей. Всего в несколько кликов!</p>
    </div>
    <div class="feature-card">
        <h3>⭐ Гарантия качества</h3>
        <p>Только свежие продукты и профессиональные повара с многолетним опытом</p>
    </div>
    <div class="feature-card">
        <h3>💖 Особенная атмосфера</h3>
        <p>Уютный интерьер, живая музыка по выходным и внимательный персонал</p>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>