<?php
require_once 'config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin']) {
    header('Location: /login.php');
    exit();
}

$message = '';

// Обработка отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $booking_id = (int)($_POST['booking_id'] ?? 0);
    $rating = (int)($_POST['rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');
    
    // Проверяем, что бронирование принадлежит пользователю и статус "Посещение состоялось"
    $stmt = $pdo->prepare("SELECT id FROM bookings WHERE id = ? AND user_id = ? AND status = 'Посещение состоялось'");
    $stmt->execute([$booking_id, $_SESSION['user_id']]);
    $booking = $stmt->fetch();
    
    if ($booking && $rating >= 1 && $rating <= 5) {
        // Проверяем, нет ли уже отзыва
        $stmt = $pdo->prepare("SELECT id FROM reviews WHERE booking_id = ?");
        $stmt->execute([$booking_id]);
        
        if (!$stmt->fetch()) {
            $stmt = $pdo->prepare("INSERT INTO reviews (booking_id, rating, comment) VALUES (?, ?, ?)");
            $stmt->execute([$booking_id, $rating, $comment]);
            $message = '<div class="message success">Отзыв успешно добавлен!</div>';
        }
    }
}

// Получение бронирований пользователя
$stmt = $pdo->prepare("
    SELECT b.*, r.rating, r.comment 
    FROM bookings b 
    LEFT JOIN reviews r ON b.id = r.booking_id 
    WHERE b.user_id = ? 
    ORDER BY b.booking_date DESC, b.booking_time DESC
");
$stmt->execute([$_SESSION['user_id']]);
$bookings = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<div class="container">
    <h2>Мои бронирования</h2>
    
    <?php echo $message; ?>
    
    <?php if (empty($bookings)): ?>
        <div class="message">
            У вас пока нет бронирований. <a href="/book_table.php">Забронировать столик</a>
        </div>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Дата</th>
                    <th>Время</th>
                    <th>Гости</th>
                    <th>Телефон</th>
                    <th>Статус</th>
                    <th>Отзыв</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $booking): ?>
                <tr>
                    <td><?php echo date('d.m.Y', strtotime($booking['booking_date'])); ?></td>
                    <td><?php echo $booking['booking_time']; ?></td>
                    <td><?php echo $booking['guests']; ?> чел.</td>
                    <td><?php echo $booking['phone']; ?></td>
                    <td>
                        <?php 
                        $status_class = 'status-' . strtolower(str_replace(' ', '-', $booking['status']));
                        echo "<span class='$status_class'>{$booking['status']}</span>";
                        ?>
                    </td>
                    <td>
                        <?php if ($booking['status'] === 'Посещение состоялось'): ?>
                            <?php if ($booking['rating']): ?>
                                <div class="rating-stars">
                                    <?php echo str_repeat('★', $booking['rating']) . str_repeat('☆', 5 - $booking['rating']); ?>
                                </div>
                                <?php if ($booking['comment']): ?>
                                    <p><em>"<?php echo htmlspecialchars($booking['comment']); ?>"</em></p>
                                <?php endif; ?>
                            <?php else: ?>
                                <form method="POST" class="review-form">
                                    <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                    <div style="margin-bottom: 10px;">
                                        <label>Оценка:</label><br>
                                        <select name="rating" required style="padding: 5px;">
                                            <option value="">Выберите оценку</option>
                                            <option value="1">1 ★</option>
                                            <option value="2">2 ★★</option>
                                            <option value="3">3 ★★★</option>
                                            <option value="4">4 ★★★★</option>
                                            <option value="5">5 ★★★★★</option>
                                        </select>
                                    </div>
                                    <div style="margin-bottom: 10px;">
                                        <label>Комментарий:</label><br>
                                        <textarea name="comment" rows="3" style="width: 100%; padding: 5px;"></textarea>
                                    </div>
                                    <button type="submit" name="submit_review" class="btn btn-success" style="padding: 8px 16px;">Оставить отзыв</button>
                                </form>
                            <?php endif; ?>
                        <?php else: ?>
                            <em>Отзыв доступен после посещения</em>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>