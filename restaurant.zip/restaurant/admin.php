<?php
require_once 'config/database.php';

if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: /login.php');
    exit();
}

$message = '';

// Обработка изменения статуса
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_status'])) {
    $booking_id = (int)($_POST['booking_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    
    $valid_statuses = ['Новое', 'Посещение состоялось', 'Отменено'];
    
    if ($booking_id > 0 && in_array($status, $valid_statuses)) {
        $stmt = $pdo->prepare("UPDATE bookings SET status = ? WHERE id = ?");
        $stmt->execute([$status, $booking_id]);
        $message = '<div class="message success">Статус обновлен!</div>';
    }
}

// Получение всех бронирований
$stmt = $pdo->query("
    SELECT b.*, u.first_name, u.last_name, u.email, u.phone as user_phone 
    FROM bookings b 
    JOIN users u ON b.user_id = u.id 
    ORDER BY b.created_at DESC
");
$bookings = $stmt->fetchAll();

// Получение статистики
$stats_stmt = $pdo->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'Новое' THEN 1 ELSE 0 END) as new,
        SUM(CASE WHEN status = 'Посещение состоялось' THEN 1 ELSE 0 END) as visited,
        SUM(CASE WHEN status = 'Отменено' THEN 1 ELSE 0 END) as cancelled
    FROM bookings
");
$stats = $stats_stmt->fetch();

require_once 'includes/header.php';
?>

<div class="container">
    <h2>Панель администратора</h2>
    
    <?php echo $message; ?>
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0;">
        <div style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h3 style="color: #3498db;">Всего бронирований</h3>
            <p style="font-size: 36px; font-weight: bold;"><?php echo $stats['total']; ?></p>
        </div>
        <div style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h3 style="color: #3498db;">Новые</h3>
            <p style="font-size: 36px; font-weight: bold;"><?php echo $stats['new']; ?></p>
        </div>
        <div style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h3 style="color: #27ae60;">Посещено</h3>
            <p style="font-size: 36px; font-weight: bold;"><?php echo $stats['visited']; ?></p>
        </div>
        <div style="background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h3 style="color: #e74c3c;">Отменено</h3>
            <p style="font-size: 36px; font-weight: bold;"><?php echo $stats['cancelled']; ?></p>
        </div>
    </div>
    
    <h3>Все бронирования</h3>
    
    <?php if (empty($bookings)): ?>
        <div class="message">
            Нет бронирований
        </div>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Клиент</th>
                    <th>Дата</th>
                    <th>Время</th>
                    <th>Гости</th>
                    <th>Телефон</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $booking): ?>
                <tr>
                    <td><?php echo $booking['id']; ?></td>
                    <td>
                        <strong><?php echo $booking['first_name'] . ' ' . $booking['last_name']; ?></strong><br>
                        <small><?php echo $booking['email']; ?></small><br>
                        <small><?php echo $booking['user_phone']; ?></small>
                    </td>
                    <td><?php echo date('d.m.Y', strtotime($booking['booking_date'])); ?></td>
                    <td><?php echo $booking['booking_time']; ?></td>
                    <td><?php echo $booking['guests']; ?> чел.</td>
                    <td><?php echo $booking['phone']; ?></td>
                    <td>
                        <?php 
                        $status_class = 'status-' . strtolower(str_replace(' ', '-', $booking['status']));
                        echo "<span class='$status_class'>{$booking['status']}</span>";
                        ?>
                    </td>
                    <td>
                        <form method="POST" style="display: flex; gap: 5px;">
                            <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                            <select name="status" style="padding: 5px; border: 1px solid #ddd; border-radius: 3px;">
                                <option value="Новое" <?php echo $booking['status'] === 'Новое' ? 'selected' : ''; ?>>Новое</option>
                                <option value="Посещение состоялось" <?php echo $booking['status'] === 'Посещение состоялось' ? 'selected' : ''; ?>>Посещение состоялось</option>
                                <option value="Отменено" <?php echo $booking['status'] === 'Отменено' ? 'selected' : ''; ?>>Отменено</option>
                            </select>
                            <button type="submit" name="change_status" class="btn" style="padding: 5px 10px; font-size: 14px;">Обновить</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>