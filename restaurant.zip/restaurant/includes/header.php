<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ресторан "Я буду кушац"</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <h1 class="logo">🍽️ Я буду кушац</h1>
            <nav class="nav">
                <a href="/" class="nav-link">Главная</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="/bookings.php" class="nav-link">Мои бронирования</a>
                    <a href="/book_table.php" class="nav-link">Забронировать столик</a>
                    <a href="/logout.php" class="nav-link">Выход</a>
                    <span class="user-info">Привет, <?php echo $_SESSION['first_name']; ?>!</span>
                <?php else: ?>
                    <a href="/login.php" class="nav-link">Вход</a>
                    <a href="/register.php" class="nav-link">Регистрация</a>
                <?php endif; ?>
                <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                    <a href="/admin.php" class="nav-link admin-link">Панель администратора</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="main container">