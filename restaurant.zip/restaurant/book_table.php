<?php
require_once 'config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin']) {
    header('Location: /login.php');
    exit();
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_date = $_POST['booking_date'] ?? '';
    $booking_time = $_POST['booking_time'] ?? '';
    $guests = (int)($_POST['guests'] ?? 1);
    $phone = trim($_POST['phone'] ?? '');
    
    // Проверка валидности даты
    $booking_datetime = strtotime($booking_date);
    $today = strtotime(date('Y-m-d'));
    
    if ($booking_datetime < $today) {
        $message = '<div class="message error">Нельзя забронировать столик на прошедшую дату</div>';
    } elseif ($guests < 1 || $guests > 10) {
        $message = '<div class="message error">Количество гостей должно быть от 1 до 10</div>';
    } elseif (!preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) {
        $message = '<div class="message error">Телефон должен быть в формате +7(XXX)-XXX-XX-XX</div>';
    } else {
        // Сохранение бронирования
        $stmt = $pdo->prepare("INSERT INTO bookings (user_id, booking_date, booking_time, guests, phone) 
                               VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], $booking_date, $booking_time, $guests, $phone]);
        
        $message = '<div class="message success">Бронирование успешно отправлено на рассмотрение администратору!</div>';
    }
}

require_once 'includes/header.php';
?>

<div class="form-container">
    <h2>Бронирование столика</h2>
    
    <?php echo $message; ?>
    
    <form method="POST" action="">
        <div class="form-group">
            <label for="booking_date">Дата:</label>
            <input type="date" id="booking_date" name="booking_date" class="form-control" required
                   min="<?php echo date('Y-m-d'); ?>">
        </div>
        
        <div class="form-group">
            <label for="booking_time">Время:</label>
            <input type="time" id="booking_time" name="booking_time" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label for="guests">Количество гостей (1-10):</label>
            <input type="number" id="guests" name="guests" class="form-control" required 
                   min="1" max="10" value="2">
        </div>
        
        <div class="form-group">
            <label for="phone">Контактный телефон:</label>
            <input type="tel" id="phone" name="phone" class="form-control" required 
                   pattern="\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}" 
                   title="Формат: +7(XXX)-XXX-XX-XX">
        </div>
        
        <button type="submit" class="btn">Забронировать</button>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>