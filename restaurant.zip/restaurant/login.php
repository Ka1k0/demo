<?php
require_once 'config/database.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($login === 'admin' && $password === 'restaurant') {
        // Администратор
        $_SESSION['user_id'] = 0;
        $_SESSION['login'] = 'admin';
        $_SESSION['first_name'] = 'Администратор';
        $_SESSION['is_admin'] = true;
        header('Location: /admin.php');
        exit();
    }
    
    // Обычный пользователь
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['login'] = $user['login'];
        $_SESSION['first_name'] = $user['first_name'];
        $_SESSION['is_admin'] = false;
        header('Location: /');
        exit();
    } else {
        $error = 'Неверный логин или пароль';
    }
}

require_once 'includes/header.php';
?>

<div class="form-container">
    <h2>Вход в систему</h2>
    
    <?php if ($error): ?>
        <div class="message error">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" action="">
        <div class="form-group">
            <label for="login">Логин:</label>
            <input type="text" id="login" name="login" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" class="form-control" required>
        </div>
        
        <button type="submit" class="btn">Войти</button>
    </form>
    
    <p style="text-align: center; margin-top: 15px;">
        Нет аккаунта? <a href="/register.php">Зарегистрироваться</a>
    </p>
    
    <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 5px;">
        <p><strong>Тестовые данные:</strong></p>
        <p>Администратор: логин <code>admin</code>, пароль <code>restaurant</code></p>
        <p>Пользователь: логин <code>testuser</code>, пароль <code>123456</code></p>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>